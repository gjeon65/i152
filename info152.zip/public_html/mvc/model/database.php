<?php

$dsn = "mysql:host=twilbury.cs.drexel.edu;dbname=gj65";
$username = "gj65";
$password = "gdjzvpttmq";
        
$db = new PDO($dsn,$username,$password);
?>