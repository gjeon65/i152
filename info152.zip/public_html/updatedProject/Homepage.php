<!DOCTYPE html>
<!--
================================
Project Name: Albums - Homepage
Date: 3/9/17
Progammer Names: Joseph Pantano, Amit Hadad, and Geun Joen
Team 152
================================
-->

<html>

<head>
<meta charset = "utf-8">
<title>Welcome to Albums!</title>
<body bgcolor="#E6E6FA">
<style type ="text/css">
</style>

</head>

<body>
<title>Welcome to Albums!</title>  
<h1><center><u>
Albums
</h1></center></u>

	Here at Albums, you can upload your photos to albums for people to view and anonymously comment on!
</h2></center>

<!-- buttons -->
<center>
<form action="https://www.cs.drexel.edu/~gj65/Project/View_Albums.php">
    <input type="submit" value="View Albums"/></form><br>
    <!-- On the viewing page, you can comment anonymously -->
<form action="https://www.cs.drexel.edu/~gj65/Project/Upload_Pictures.php">
    <input type="submit" value="Create your own Album"/>
</form>     
</center>
<!--
<script type="text/javascript">
</script>
-->

<!-- show albums below? -->
<h3>
<a href="https://www.cs.drexel.edu/~jtp53/Project/Project_Goals.html">Project Goals</a>
</h3>
</body>

<html>
<h2><center>
