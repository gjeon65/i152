<!DOCTYPE html>
<!-- Goals for the project -->
<html>

<head>
<meta charset = "utf-8">
<title>Welcome to Albums!</title>

<style type="text/css">

</style>

</head>

<body>

<h1><center>
Project Goals
</h1></center>

<h2>
In Albums, we seek to accomplish the following goals:
</h2></br>
<h3>
-Create tables for photos, albums, and messages using MySQL</br>
-Use PhP code to:</br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-View photos in a grid view</br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-Upload photos to a database</br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-Create new Albums</br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-View existing albums</br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-View existing photos in an album</br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-Delete submitted photos from album</br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-Anonymously comment on photos/albums</br>
</h3>
<br>
<br>
       <form action="https://www.cs.drexel.edu/~gj65/Project/Homepage.php">
    <input type="submit" value="Homepage"/>
</body>
</html>