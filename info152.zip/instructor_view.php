<!DOCTYPE html>
<html>
	<head><title>Instructor's View of PHP Code</title></head>
<body>
<?php
$page = $_GET["page"]; 
show_source($page);
?>

</body>
</html>